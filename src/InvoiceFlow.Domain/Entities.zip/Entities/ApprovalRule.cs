namespace InvoiceFlow.Domain.Entities;

/// <summary>
/// Admin-configurable rule defining which roles must approve invoices based on amount thresholds.
/// Rules are evaluated in ascending MaxAmount order; the first matching rule wins.
/// A rule with MaxAmount = decimal.MaxValue acts as the catch-all for highest amounts.
/// </summary>
public sealed class ApprovalRule
{
    public int Id { get; private set; }

    /// <summary>
    /// Upper bound (inclusive) of the invoice amount for this rule.
    /// Use decimal.MaxValue for the highest tier (no upper limit).
    /// </summary>
    public decimal MaxAmount { get; private set; }

    /// <summary>
    /// JSON array of UserRole enum values defining the sequential approval chain.
    /// Example: [2, 3] = Manager then FinanceHead.
    /// </summary>
    public string RequiredRoles { get; private set; } = "[]";

    public DateTime LastUpdatedAt { get; private set; } = DateTime.UtcNow;
    public Guid LastUpdatedByUserId { get; private set; }

    private ApprovalRule() { } // Required by EF Core

    public static ApprovalRule Create(
        int id,
        decimal maxAmount,
        string requiredRolesJson,
        Guid updatedByUserId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(requiredRolesJson);

        return new ApprovalRule
        {
            Id = id,
            MaxAmount = maxAmount,
            RequiredRoles = requiredRolesJson,
            LastUpdatedByUserId = updatedByUserId,
            LastUpdatedAt = DateTime.UtcNow
        };
    }

    public void Update(decimal maxAmount, string requiredRolesJson, Guid updatedByUserId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(requiredRolesJson);

        MaxAmount = maxAmount;
        RequiredRoles = requiredRolesJson;
        LastUpdatedByUserId = updatedByUserId;
        LastUpdatedAt = DateTime.UtcNow;
    }
}
