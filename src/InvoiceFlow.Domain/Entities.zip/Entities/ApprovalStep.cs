using InvoiceFlow.Domain.Common;
using InvoiceFlow.Domain.Enums;
using InvoiceFlow.Domain.Events;

namespace InvoiceFlow.Domain.Entities;

/// <summary>
/// A single step in an approval workflow, assigned to a user with a specific role.
/// Approval decisions raise domain events consumed by the application layer
/// to progress the workflow and notify relevant parties.
/// </summary>
public sealed class ApprovalStep : BaseEntity
{
    public Guid WorkflowId { get; private set; }

    /// <summary>Invoice this step belongs to — denormalized for efficient queries.</summary>
    public Guid InvoiceId { get; private set; }

    /// <summary>Position in the sequential approval chain (1-based).</summary>
    public int StepNumber { get; private set; }

    public UserRole RequiredRole { get; private set; }
    public Guid? AssignedToUserId { get; private set; }
    public ApprovalStepStatus Status { get; private set; } = ApprovalStepStatus.Pending;
    public string? Comment { get; private set; }
    public DateTime? DecidedAt { get; private set; }

    /// <summary>Original assignee if this step was delegated.</summary>
    public Guid? DelegatedFromUserId { get; private set; }

    /// <summary>Timestamp of the 48-hour reminder notification.</summary>
    public DateTime? ReminderSentAt { get; private set; }

    /// <summary>Timestamp when the step was escalated to the assigner's manager (72h).</summary>
    public DateTime? EscalatedAt { get; private set; }

    // Navigation — populated by EF Core
    public ApprovalWorkflow? Workflow { get; private set; }

    private ApprovalStep() { } // Required by EF Core

    public static ApprovalStep Create(
        Guid workflowId,
        Guid invoiceId,
        int stepNumber,
        UserRole requiredRole,
        Guid? assignedToUserId) => new()
        {
            WorkflowId = workflowId,
            InvoiceId = invoiceId,
            StepNumber = stepNumber,
            RequiredRole = requiredRole,
            AssignedToUserId = assignedToUserId
        };

    /// <summary>Approves this step with an optional comment.</summary>
    public void Approve(string? comment)
    {
        EnsurePending();

        Status = ApprovalStepStatus.Approved;
        Comment = comment?.Trim();
        DecidedAt = DateTime.UtcNow;
        MarkUpdated();

        RaiseDomainEvent(new ApprovalDecisionEvent(
            WorkflowId, InvoiceId, Id, ApprovalStepStatus.Approved, AssignedToUserId));
    }

    /// <summary>Rejects this step. A non-empty comment is mandatory.</summary>
    public void Reject(string comment)
    {
        EnsurePending();
        ArgumentException.ThrowIfNullOrWhiteSpace(comment);

        Status = ApprovalStepStatus.Rejected;
        Comment = comment.Trim();
        DecidedAt = DateTime.UtcNow;
        MarkUpdated();

        RaiseDomainEvent(new ApprovalDecisionEvent(
            WorkflowId, InvoiceId, Id, ApprovalStepStatus.Rejected, AssignedToUserId));
    }

    /// <summary>
    /// Delegates this step to another eligible user.
    /// The current step is closed as Delegated; the caller must create a new step for the target user.
    /// </summary>
    public void Delegate(Guid delegatedToUserId)
    {
        EnsurePending();
        if (delegatedToUserId == AssignedToUserId)
            throw new InvalidOperationException("Cannot delegate a step to the same assignee.");

        DelegatedFromUserId = AssignedToUserId;
        AssignedToUserId = delegatedToUserId;
        Status = ApprovalStepStatus.Delegated;
        DecidedAt = DateTime.UtcNow;
        MarkUpdated();
    }

    public void MarkReminderSent()
    {
        ReminderSentAt = DateTime.UtcNow;
        MarkUpdated();
    }

    public void MarkEscalated()
    {
        EscalatedAt = DateTime.UtcNow;
        MarkUpdated();
    }

    /// <summary>Reassigns the step to a new user (used during escalation).</summary>
    public void Reassign(Guid newUserId)
    {
        EnsurePending();
        AssignedToUserId = newUserId;
        MarkUpdated();
    }

    private void EnsurePending()
    {
        if (Status != ApprovalStepStatus.Pending)
            throw new InvalidOperationException(
                $"Cannot perform action on a step with status '{Status}'.");
    }
}
