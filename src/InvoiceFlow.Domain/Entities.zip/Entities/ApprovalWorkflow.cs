using InvoiceFlow.Domain.Common;

namespace InvoiceFlow.Domain.Entities;

/// <summary>
/// Orchestrates the multi-step approval process for an invoice.
/// Created after successful AI extraction, based on ApprovalRules for the invoice amount.
/// One-to-one with Invoice.
/// </summary>
public sealed class ApprovalWorkflow : BaseEntity
{
    public Guid InvoiceId { get; private set; }

    /// <summary>The step number currently awaiting action (1-based).</summary>
    public int CurrentStepNumber { get; private set; } = 1;

    public int TotalSteps { get; private set; }
    public DateTime? CompletedAt { get; private set; }

    // Navigation — populated by EF Core
    public Invoice? Invoice { get; private set; }
    public ICollection<ApprovalStep> Steps { get; private set; } = [];

    private ApprovalWorkflow() { } // Required by EF Core

    public static ApprovalWorkflow Create(Guid invoiceId, int totalSteps)
    {
        ArgumentOutOfRangeException.ThrowIfLessThan(totalSteps, 1);

        return new ApprovalWorkflow
        {
            InvoiceId = invoiceId,
            TotalSteps = totalSteps,
            CurrentStepNumber = 1
        };
    }

    /// <summary>Advances the workflow to the next step after the current step is approved.</summary>
    public void AdvanceToNextStep()
    {
        if (CurrentStepNumber < TotalSteps)
        {
            CurrentStepNumber++;
            MarkUpdated();
        }
    }

    /// <summary>Marks the workflow as fully completed (all steps approved).</summary>
    public void Complete()
    {
        CompletedAt = DateTime.UtcNow;
        MarkUpdated();
    }

    public bool IsOnLastStep => CurrentStepNumber == TotalSteps;
    public bool IsCompleted => CompletedAt.HasValue;
}
