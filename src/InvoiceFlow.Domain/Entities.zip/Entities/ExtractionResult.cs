using InvoiceFlow.Domain.Common;
using InvoiceFlow.Domain.Events;

namespace InvoiceFlow.Domain.Entities;

/// <summary>
/// Holds the structured data extracted from an invoice by Azure AI Document Intelligence.
/// One-to-one with Invoice. Confidence scores below 0.70 flag the invoice for manual correction.
/// </summary>
public sealed class ExtractionResult : BaseEntity
{
    public Guid InvoiceId { get; private set; }

    // Core extracted fields
    public string? VendorName { get; private set; }
    public string? InvoiceNumber { get; private set; }
    public DateTime? InvoiceDate { get; private set; }
    public DateTime? DueDate { get; private set; }
    public decimal? TotalAmount { get; private set; }
    public string? Currency { get; private set; }
    public decimal? SubTotal { get; private set; }
    public decimal? TaxAmount { get; private set; }

    /// <summary>
    /// JSON object: { "VendorName": 0.95, "TotalAmount": 0.62, ... }
    /// Fields with confidence &lt; 0.70 are highlighted in the UI for manual correction.
    /// </summary>
    public string ConfidenceScores { get; private set; } = "{}";

    /// <summary>True if any field has confidence below 0.70.</summary>
    public bool HasLowConfidenceFields { get; private set; }

    public bool IsManuallyCorrected { get; private set; }
    public DateTime ExtractedAt { get; private set; }
    public DateTime? CorrectedAt { get; private set; }
    public Guid? CorrectedByUserId { get; private set; }

    // Navigation — populated by EF Core
    public Invoice? Invoice { get; private set; }
    public ICollection<InvoiceLineItem> LineItems { get; private set; } = [];

    private ExtractionResult() { } // Required by EF Core

    /// <summary>Creates an extraction result and raises ExtractionCompletedEvent.</summary>
    public static ExtractionResult Create(
        Guid invoiceId,
        string? vendorName,
        string? invoiceNumber,
        DateTime? invoiceDate,
        DateTime? dueDate,
        decimal? totalAmount,
        decimal? subTotal,
        decimal? taxAmount,
        string? currency,
        string confidenceScoresJson,
        bool hasLowConfidenceFields)
    {
        var result = new ExtractionResult
        {
            InvoiceId = invoiceId,
            VendorName = vendorName,
            InvoiceNumber = invoiceNumber,
            InvoiceDate = invoiceDate,
            DueDate = dueDate,
            TotalAmount = totalAmount,
            SubTotal = subTotal,
            TaxAmount = taxAmount,
            Currency = currency,
            ConfidenceScores = confidenceScoresJson,
            HasLowConfidenceFields = hasLowConfidenceFields,
            ExtractedAt = DateTime.UtcNow
        };

        result.RaiseDomainEvent(new ExtractionCompletedEvent(
            invoiceId,
            result.Id,
            hasLowConfidenceFields,
            totalAmount));

        return result;
    }

    /// <summary>
    /// Applies manual corrections to AI-extracted fields.
    /// Records who corrected it and when.
    /// </summary>
    public void ApplyManualCorrection(
        string? vendorName,
        string? invoiceNumber,
        DateTime? invoiceDate,
        DateTime? dueDate,
        decimal? totalAmount,
        decimal? subTotal,
        decimal? taxAmount,
        string? currency,
        Guid correctedByUserId)
    {
        VendorName = vendorName;
        InvoiceNumber = invoiceNumber;
        InvoiceDate = invoiceDate;
        DueDate = dueDate;
        TotalAmount = totalAmount;
        SubTotal = subTotal;
        TaxAmount = taxAmount;
        Currency = currency;
        IsManuallyCorrected = true;
        CorrectedAt = DateTime.UtcNow;
        CorrectedByUserId = correctedByUserId;
        MarkUpdated();
    }
}
