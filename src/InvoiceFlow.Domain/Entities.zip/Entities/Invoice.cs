using InvoiceFlow.Domain.Common;
using InvoiceFlow.Domain.Enums;
using InvoiceFlow.Domain.Events;

namespace InvoiceFlow.Domain.Entities;

/// <summary>
/// Core aggregate root representing an invoice in the system.
/// Owns its extraction result, approval workflow, and audit logs.
/// Status transitions are validated to prevent illegal state changes.
/// </summary>
public sealed class Invoice : BaseEntity
{
    public Guid VendorId { get; private set; }

    /// <summary>Blob Storage path: invoices/{year}/{month}/{guid}{ext}</summary>
    public string BlobPath { get; private set; } = string.Empty;

    public string OriginalFileName { get; private set; } = string.Empty;
    public long FileSizeBytes { get; private set; }
    public InvoiceStatus Status { get; private set; } = InvoiceStatus.Uploaded;
    public Guid UploadedByUserId { get; private set; }
    public DateTime UploadedAt { get; private set; }

    /// <summary>
    /// SHA-256 hash of (VendorId + InvoiceNumber + TotalAmount).
    /// Computed after extraction. Used for O(1) duplicate detection.
    /// </summary>
    public string? DuplicateCheckHash { get; private set; }

    // Navigation — populated by EF Core
    public Vendor? Vendor { get; private set; }
    public ExtractionResult? ExtractionResult { get; private set; }
    public ApprovalWorkflow? ApprovalWorkflow { get; private set; }
    public ICollection<AuditLog> AuditLogs { get; private set; } = [];

    private Invoice() { } // Required by EF Core

    /// <summary>
    /// Creates a new invoice record and raises InvoiceUploadedEvent to trigger async extraction.
    /// </summary>
    public static Invoice Create(
        Guid vendorId,
        string blobPath,
        string originalFileName,
        long fileSizeBytes,
        Guid uploadedByUserId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(blobPath);
        ArgumentException.ThrowIfNullOrWhiteSpace(originalFileName);

        var invoice = new Invoice
        {
            VendorId = vendorId,
            BlobPath = blobPath,
            OriginalFileName = originalFileName,
            FileSizeBytes = fileSizeBytes,
            UploadedByUserId = uploadedByUserId,
            UploadedAt = DateTime.UtcNow
        };

        invoice.RaiseDomainEvent(new InvoiceUploadedEvent(invoice.Id, vendorId, blobPath));
        return invoice;
    }

    /// <summary>
    /// Transitions the invoice to a new status, enforcing valid state machine paths.
    /// </summary>
    public void TransitionStatus(InvoiceStatus newStatus)
    {
        ValidateStatusTransition(Status, newStatus);
        Status = newStatus;
        MarkUpdated();
    }

    public void SetDuplicateCheckHash(string hash)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(hash);
        DuplicateCheckHash = hash;
        MarkUpdated();
    }

    private static readonly Dictionary<InvoiceStatus, HashSet<InvoiceStatus>> ValidTransitions = new()
    {
        [InvoiceStatus.Uploaded]        = [InvoiceStatus.Extracting],
        [InvoiceStatus.Extracting]      = [InvoiceStatus.Extracted, InvoiceStatus.Rejected],
        [InvoiceStatus.Extracted]       = [InvoiceStatus.PendingApproval],
        [InvoiceStatus.PendingApproval] = [InvoiceStatus.InApproval],
        [InvoiceStatus.InApproval]      = [InvoiceStatus.Approved, InvoiceStatus.Rejected],
        [InvoiceStatus.Approved]        = [],
        [InvoiceStatus.Rejected]        = []
    };

    private static void ValidateStatusTransition(InvoiceStatus from, InvoiceStatus to)
    {
        if (!ValidTransitions.TryGetValue(from, out var allowed) || !allowed.Contains(to))
            throw new InvalidOperationException(
                $"Invalid invoice status transition: {from} → {to}.");
    }
}
