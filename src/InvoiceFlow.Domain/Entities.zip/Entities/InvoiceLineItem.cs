using InvoiceFlow.Domain.Common;

namespace InvoiceFlow.Domain.Entities;

/// <summary>
/// A single line item from an invoice, extracted by Azure AI Document Intelligence.
/// Belongs to an ExtractionResult. Confidence below 0.70 is flagged in the UI.
/// </summary>
public sealed class InvoiceLineItem : BaseEntity
{
    public Guid ExtractionResultId { get; private set; }
    public string? Description { get; private set; }
    public decimal? Quantity { get; private set; }
    public decimal? UnitPrice { get; private set; }
    public decimal? Amount { get; private set; }

    /// <summary>AI confidence score for this line item (0.0 – 1.0).</summary>
    public decimal Confidence { get; private set; }

    // Navigation — populated by EF Core
    public ExtractionResult? ExtractionResult { get; private set; }

    private InvoiceLineItem() { } // Required by EF Core

    public static InvoiceLineItem Create(
        Guid extractionResultId,
        string? description,
        decimal? quantity,
        decimal? unitPrice,
        decimal? amount,
        decimal confidence) => new()
        {
            ExtractionResultId = extractionResultId,
            Description = description,
            Quantity = quantity,
            UnitPrice = unitPrice,
            Amount = amount,
            Confidence = confidence
        };
}
