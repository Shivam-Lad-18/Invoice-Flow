namespace InvoiceFlow.Domain.Entities;

/// <summary>
/// Persisted refresh token for rolling JWT refresh.
/// Stored in the database; invalidated on logout or rotation.
/// A token is active only when it is not revoked and not expired.
/// </summary>
public sealed class RefreshToken
{
    public Guid Id { get; private set; } = Guid.NewGuid();
    public Guid UserId { get; private set; }

    /// <summary>Cryptographically random token value (Base64Url).</summary>
    public string Token { get; private set; } = string.Empty;

    public DateTime ExpiresAt { get; private set; }
    public bool IsRevoked { get; private set; }

    /// <summary>Reason for revocation, e.g. "Logout", "Rotated", "SecurityBreach".</summary>
    public string? RevokedReason { get; private set; }

    /// <summary>The token that replaced this one when rotated on refresh.</summary>
    public string? ReplacedByToken { get; private set; }

    public DateTime CreatedAt { get; private set; } = DateTime.UtcNow;

    public bool IsExpired => DateTime.UtcNow >= ExpiresAt;
    public bool IsActive => !IsRevoked && !IsExpired;

    private RefreshToken() { } // Required by EF Core

    public static RefreshToken Create(Guid userId, string token, int expiryDays = 7)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(token);
        ArgumentOutOfRangeException.ThrowIfLessThan(expiryDays, 1);

        return new RefreshToken
        {
            UserId = userId,
            Token = token,
            ExpiresAt = DateTime.UtcNow.AddDays(expiryDays)
        };
    }

    public void Revoke(string reason, string? replacedByToken = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(reason);

        IsRevoked = true;
        RevokedReason = reason;
        ReplacedByToken = replacedByToken;
    }
}
