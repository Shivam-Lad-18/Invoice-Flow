using InvoiceFlow.Domain.Common;
using InvoiceFlow.Domain.Enums;

namespace InvoiceFlow.Domain.Entities;

/// <summary>
/// Registered vendor who can upload invoices.
/// Created by Admin only. May optionally have a linked user account for portal access.
/// </summary>
public sealed class Vendor : BaseEntity
{
    public string Name { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string? TaxId { get; private set; }
    public VendorStatus Status { get; private set; } = VendorStatus.Active;
    public DateTime RegisteredAt { get; private set; }
    public Guid RegisteredByUserId { get; private set; }

    /// <summary>
    /// Optional link to an ApplicationUser account for portal login.
    /// Set by Admin after creating the vendor user account.
    /// </summary>
    public Guid? UserAccountId { get; private set; }

    // Navigation — populated by EF Core
    public ICollection<Invoice> Invoices { get; private set; } = [];

    private Vendor() { } // Required by EF Core

    /// <summary>Creates a new vendor. Email is normalised to lowercase.</summary>
    public static Vendor Create(string name, string email, string? taxId, Guid registeredByUserId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentException.ThrowIfNullOrWhiteSpace(email);

        return new Vendor
        {
            Name = name.Trim(),
            Email = email.Trim().ToLowerInvariant(),
            TaxId = taxId?.Trim(),
            RegisteredByUserId = registeredByUserId,
            RegisteredAt = DateTime.UtcNow
        };
    }

    public void SetStatus(VendorStatus status)
    {
        Status = status;
        MarkUpdated();
    }

    public void LinkUserAccount(Guid userId)
    {
        UserAccountId = userId;
        MarkUpdated();
    }

    public void Update(string name, string email, string? taxId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentException.ThrowIfNullOrWhiteSpace(email);

        Name = name.Trim();
        Email = email.Trim().ToLowerInvariant();
        TaxId = taxId?.Trim();
        MarkUpdated();
    }
}
